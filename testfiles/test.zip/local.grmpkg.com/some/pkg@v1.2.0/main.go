package grmpkg

import "log"

func Main() {
	log.Println("some module")
}
